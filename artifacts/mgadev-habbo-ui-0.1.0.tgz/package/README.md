# @mgadev/habbo-ui

Componentes React organizados por año. Requiere React 18.2 o 19.

```tsx
import { Button, Card } from '@mgadev/habbo-ui/2008';
import '@mgadev/habbo-ui/2008/styles.css';

export function Example() {
  return <Card title="Noticias"><Button>Continuar</Button></Card>;
}
```

- `/2008`: Button, Card, Alert, Field, Tabs, LoginForm y Dialog, con estilos aislados.
- `/2006`: componentes de la primera biblioteca, con su hoja `/2006/styles.css`. Esta edición conserva estilos globales.
- `/2003`: Panel, OnlinePanel, HelpPanel, Navigation, NewsCard, PromoCard, Button, CheckInButton, Hero, Logo, Typography, ContactForm y WeekSelector. GIF incluidos y CSS aislado; importa `/2003/styles.css`.

El código fuente se separa en `src/2003`, `src/2006` y `src/2008`. Importa componentes y CSS desde la misma edición. La entrada raíz exporta `editions`.

Proyecto no afiliado a Habbo. Los recursos históricos conservan los derechos de sus respectivos propietarios.
